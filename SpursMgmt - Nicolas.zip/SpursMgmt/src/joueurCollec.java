import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

public class joueurCollec {
	public static List<joueur> listeJoueurs() {
	    List<joueur> liste = new ArrayList<joueur>();

        // Lecture du fichier XML
        SAXBuilder saxBuilder = new SAXBuilder();
        Document document = null;
		try {
			document = saxBuilder.build("./joueurs.xml");
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Récupération de la racine
		Element racine = document.getRootElement();
		List<Element> joueurElements = racine.getChildren("joueur");
		    for (Element joueur : joueurElements) {
		        String nom = joueur.getChildText("Nom");
		        String prenom = joueur.getChildText("Prénom");
		        String age = joueur.getChildText("Age");
		        String poid = joueur.getChildText("Poid");
		        String taille = joueur.getChildText("Taille");
		        joueur nvJoueur = new joueur(nom, prenom, Integer.parseInt(age), Integer.parseInt(poid), Integer.parseInt(taille));
		        liste.add(nvJoueur);
		}
        return liste;
    }
}
