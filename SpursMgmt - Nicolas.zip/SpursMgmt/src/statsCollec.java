import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.JDOMException;
import org.jdom2.input.SAXBuilder;

public class statsCollec {
	static joueur LeJoueur = null; // Variable utilisé dans la méthode "listeStats", pour récupérer le joueur concerné
	static match LeMatch = null; // Variable utilisé dans la méthode "listeStats", pour récupérer le match concerné
	
	public static List<statcards> listeStats(String s) {
	    List<statcards> liste = new ArrayList<statcards>();
	    List<joueur> listeJoueurs = manip.listeJoueurs();
	    List<match> ListeMatchs = manip.listeMatchs();
	    // Lecture du fichier XML
	    SAXBuilder saxBuilder = new SAXBuilder();
	    Document document = null;
		try {
			document = saxBuilder.build("./"+s+".xml");
		} catch (JDOMException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        // Récupération de la racine
		Element racine = document.getRootElement();
		List<Element> statElements = racine.getChildren("Stats");
		
		for (Element statcards : statElements) {
		        String Nom = statcards.getChildText("Nom");
		        String MatchID = statcards.getChildText("MatchID");
		        String TDJeu = statcards.getChildText("TDJeu");
		        String Points = statcards.getChildText("Points");
		        String Rebonds = statcards.getChildText("Rebonds");
		        String Passe_D = statcards.getChildText("Passe_D");
		        listeJoueurs.forEach((joueurdeListe) -> {
					if(joueurdeListe.getNom().equals(Nom)) {
						LeJoueur = joueurdeListe;
					};
					});	
				ListeMatchs.forEach((matchdeListe) -> {
					if(matchdeListe.getMatchID().equals(Integer.parseInt(MatchID))) {
						LeMatch = matchdeListe;
					};
					});
				statcards nvStat = new statcards(LeMatch, LeJoueur, TDJeu, Points, Integer.parseInt(Rebonds), Integer.parseInt(Passe_D));
		        
				liste.add(nvStat);
			}
	        return liste;
	    }
}
