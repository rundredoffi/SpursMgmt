import java.util.Scanner;

public class Usine {
	/*
	 * Méthodes pour les matchs
	 */
	public static void rechercheMatch() {
		matchCollec.remplirListeMatchs();
		Scanner s = new Scanner(System.in);
		System.out.println("Saisir l'identifiant du match recherché : ");
		String matchId = s.nextLine(); // On récupère le choix de l'utilisateur
		match leMatch = matchCollec.searchMatch(matchId);
		
		System.out.println(leMatch.toString());
	}
	public static void ajouterMatch() {
		Scanner s = new Scanner(System.in);
		System.out.println("Saisir l'identifiant du match recherché : ");
		Integer matchId = Integer.parseInt(s.nextLine()); // On récupère le choix de l'utilisateur
		
		System.out.println("Saisir l'identifiant du match recherché : ");
		String adversaire = s.nextLine(); // On récupère le choix de l'utilisateur
		
		System.out.println("Saisir l'identifiant du match recherché : ");
		String dateMatch = s.nextLine(); // On récupère le choix de l'utilisateur
		
		System.out.println("Saisir l'identifiant du match recherché : ");
		String lieu = s.nextLine(); // On récupère le choix de l'utilisateur
		
		System.out.println("Saisir l'identifiant du match recherché : ");
		String resultat = s.nextLine(); // On récupère le choix de l'utilisateur
		
		System.out.println("Saisir l'identifiant du match recherché : ");
		String difScore = s.nextLine(); // On récupère le choix de l'utilisateur
		
		match LeMatch = new match(matchId, adversaire, dateMatch, lieu, resultat, difScore);
		if(matchCollec.ajoutMatch(LeMatch)) {
			System.out.println("Match ajouté !");
		}
	}
	
}