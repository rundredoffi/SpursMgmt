import java.io.IOException;


public class program {

	public static void main(String[] args) {
		try {
			parametres.loadFichierIni("paramAppli.ini"); // Chargement des paramètres
			Usine.rechercheMatch();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}