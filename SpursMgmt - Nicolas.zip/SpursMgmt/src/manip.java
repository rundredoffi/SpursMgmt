import java.io.IOException;
import java.util.*;
import org.jdom2.*;
import org.jdom2.input.SAXBuilder;

public class manip {
	static joueur LeJoueur = null; // Variable utilisé dans la méthode "listeStats", pour récupérer le joueur concerné
	static match LeMatch = null; // Variable utilisé dans la méthode "listeStats", pour récupérer le match concerné
	/*
	 * Méthode static, renvoyant une liste d'objet joueur
	 * @return List<joueur>
	 */
	public static List<joueur> listeJoueurs() {
	    List<joueur> liste = new ArrayList<joueur>();
	
	        // Lecture du fichier XML
	        SAXBuilder saxBuilder = new SAXBuilder();
	        Document document = null;
			try {
				document = saxBuilder.build("./joueurs.xml");
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        // Récupération de la racine
			Element racine = document.getRootElement();
			List<Element> joueurElements = racine.getChildren("joueur");
			    for (Element joueur : joueurElements) {
			        String nom = joueur.getChildText("Nom");
			        String prenom = joueur.getChildText("Prénom");
			        String age = joueur.getChildText("Age");
			        String poid = joueur.getChildText("Poid");
			        String taille = joueur.getChildText("Taille");
			        joueur nvJoueur = new joueur(nom, prenom, Integer.parseInt(age), Integer.parseInt(poid), Integer.parseInt(taille));
			        liste.add(nvJoueur);
			}
	        return liste;
	    }
	/*
	 * Méthode permetant d'afficher les joueurs d'une liste de joueur passer en paramètres
	 * @params List<joueur>
	 */
	public static void AfficherJoueurs(List<joueur> liste) {
		liste.forEach((joueurdeListe) -> {
			System.out.println(joueurdeListe.toString());
			});
	}
	/*
	 * Méthode permetant d'envoyer dans la base données les joueurs d'une liste d'objet joueur
	 * @params List<joueur>
	 */
	public static void JoueursToBase(List<joueur> liste) {
		liste.forEach((joueurdeListe) -> {
			joueurdeListe.putInBdd();
			});
		}
	/*
	 * Méthode static, renvoyant une liste d'objet match
	 * @return List<match>
	 */
	public static List<match> listeMatchs() {
	    List<match> liste = new ArrayList<match>();
	        // Lecture du fichier XML
	        SAXBuilder saxBuilder = new SAXBuilder();
	        Document document = null;
			try {
				document = saxBuilder.build("./Matchs.xml");
			} catch (JDOMException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	        // Récupération de la racine
			Element racine = document.getRootElement();
			List<Element> matchElements = racine.getChildren("match");
			    for (Element match : matchElements) {
			        String MatchID = match.getChildText("MatchID");
			        String Adversaire = match.getChildText("Adversaire");
			        String Date = match.getChildText("Date");
			        String Lieu = match.getChildText("Lieu");
			        String Resultat = match.getChildText("Resultat");
			        String DifScore = match.getChildText("DifScore");
			        match nvMatch = new match(Integer.parseInt(MatchID), Adversaire, Date, Lieu, Resultat, DifScore);
			        liste.add(nvMatch);
			}
	        return liste;
	    }
	/*
	 * Méthode permetant d'afficher les match d'une liste de match passer en paramètres
	 * @params List<match>
	 */
	public static void AfficherMatchs(List<match> liste) {
		liste.forEach((matchdeListe) -> {
			System.out.println(matchdeListe.toString());
			});
		}
	/*
	 * Méthode permetant d'envoyer dans la base données les matchs d'une liste d'objet match
	 * @params List<match>
	 */
	public static void MatchsToBase(List<match> liste) {
		liste.forEach((matchdeListe) -> {
			matchdeListe.putInBdd();
			});
	}
	/*
	 * Méthode static, renvoyant une liste d'objet statcards
	 * @return List<statcards>
	 */
	public static List<statcards> listeStats(String s) {
	    List<statcards> liste = new ArrayList<statcards>();
	    List<joueur> listeJoueurs = manip.listeJoueurs();
	    List<match> ListeMatchs = manip.listeMatchs();
	    // Lecture du fichier XML
	    SAXBuilder saxBuilder = new SAXBuilder();
	    Document document = null;
				try {
					document = saxBuilder.build("./"+s+".xml");
				} catch (JDOMException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		        // Récupération de la racine
				Element racine = document.getRootElement();
				List<Element> statElements = racine.getChildren("Stats");
				
				for (Element statcards : statElements) {
				        String Nom = statcards.getChildText("Nom");
				        String MatchID = statcards.getChildText("MatchID");
				        String TDJeu = statcards.getChildText("TDJeu");
				        String Points = statcards.getChildText("Points");
				        String Rebonds = statcards.getChildText("Rebonds");
				        String Passe_D = statcards.getChildText("Passe_D");
				        listeJoueurs.forEach((joueurdeListe) -> {
							if(joueurdeListe.getNom().equals(Nom)) {
								LeJoueur = joueurdeListe;
							};
							});	
						ListeMatchs.forEach((matchdeListe) -> {
							if(matchdeListe.getMatchID().equals(Integer.parseInt(MatchID))) {
								LeMatch = matchdeListe;
							};
							});
						statcards nvStat = new statcards(LeMatch, LeJoueur, TDJeu, Points, Integer.parseInt(Rebonds), Integer.parseInt(Passe_D));
				        
						liste.add(nvStat);
				}
	        return liste;
	    }
	/*
	 * Méthode permetant d'afficher les statistiques d'une liste de statistique passer en paramètres
	 * @params List<statcards>
	 */
	public static void AfficherStats(List<statcards> mesStats) {
		mesStats.forEach((statdeListe) -> {
			System.out.println(statdeListe.toString());
			});
		}
	/*
	 * Méthode permetant d'envoyer dans la base données les statistiques d'une liste d'objet statcards
	 * @params List<statcards>
	 */
	public static void StatsToBase(List<statcards> liste) {
	liste.forEach((statdeListe) -> {
		statdeListe.putInBdd();
		});
}
	/*
	 * Afficher le menu de l'application dans la console
	 */
	public static void afficherMenu() 
    {
        String choix ="";

        while (!choix.equals("4")) // Tant que le choix est différent de quitter le programme
        {
            System.out.println("\nMenu de l'application de gestion des Spurs : \n"); // On affiche le menu
            System.out.println("1 - L'équipe \n");
            System.out.println("2 - Les matchs \n");
            System.out.println("3 - Les statistiques \n");
            System.out.println("4 - Quitter l'application \n");

            Scanner nombre = new Scanner(System.in);
			System.out.println("Saisir votre choix : ");
			choix = nombre.nextLine(); // On récupère le choix de l'utilisateur
			
            if (!choix.equals("4"))
            switch (choix) // On effectue le choix de l'utilisateur
            {
                case "1": // Créer le fichier
                	menuEquipe();
                    break;

                case "2": // Ecrire dans le fichier
                	menuMatchs();
                    break;

                case "3": // Afficher le contenu du fichier
                	menuStats();
                    break;

                default: // Si l'utilisateur entre autre chose que souhaité
                    System.out.println("Vous devez saisir un choix compris entre 1 et 3");
                    break;
            }
            
        }
    }
	private static void menuEquipe() 
    {
        String choix ="";

        while (!choix.equals("3")) // Tant que le choix est différent de quitter le programme
        {
            System.out.println("\nMenu de l'application de gestion des Spurs : \n"); // On affiche le menu
            System.out.println("1 - Afficher les joueurs \n");
            System.out.println("2 - Ajouter les joueurs à la base de données \n");
            System.out.println("3 - Quitter le sous-menu \n");

            Scanner nombre = new Scanner(System.in);
			System.out.println("Saisir votre choix : ");
			choix = nombre.nextLine(); // On récupère le choix de l'utilisateur
			if (!choix.equals("3"))
            switch (choix) // On effectue le choix de l'utilisateur
            {
                case "1": // Afficher les joueurs
                    List<joueur> ListeJoueurs= manip.listeJoueurs();
                    manip.AfficherJoueurs(ListeJoueurs);
                    break;

                case "2": // Envoie des joueurs dans la base
                    List<joueur> ListeJoueur = manip.listeJoueurs();
                    manip.JoueursToBase(ListeJoueur);
                    break;

                default: // Si l'utilisateur entre autre chose que souhaité
                    System.out.println("Vous devez saisir un choix compris entre 1 et 2");
                    break;
            }
	        manip.afficherMenu();
        }
    }
	private static void menuMatchs() 
    {
        String choix ="";

        while (!choix.equals("3")) // Tant que le choix est différent de quitter le programme
        {
            List<match> ListeMatch = manip.listeMatchs();
            System.out.println("\nMenu de l'application de gestion des Spurs : \n"); // On affiche le menu
            System.out.println("1 - Afficher les matchs \n");
            System.out.println("2 - Ajouter les matchs à la base de données \n");
            System.out.println("3 - Quitter le sous-menu \n");


        	Scanner nombre = new Scanner(System.in);
			System.out.println("Saisir votre choix : ");
			choix = nombre.nextLine(); // On récupère le choix de l'utilisateur

            if (!choix.equals("3"))
            switch (choix) // On effectue le choix de l'utilisateur
            {
                case "1": // Afficher les matchs
                    manip.AfficherMatchs(ListeMatch);
                    break;

                case "2": // Envoie des matchs dans la base
                    manip.MatchsToBase(ListeMatch);
                    break;

                default: // Si l'utilisateur entre autre chose que souhaité
                    System.out.println("Vous devez saisir un choix compris entre 1 et 2");
                    break;
            }
        }
        manip.afficherMenu();
    }
	private static void menuStats() 
    {
        String choix ="";
        Scanner s = new Scanner(System.in);
		System.out.println("Saisir le nom de l'équipe que vous souhaitez consulter : ");
		String equipe = s.nextLine(); // On récupère le choix de l'utilisateur
		
        while (!choix.equals("3")) // Tant que le choix est différent de quitter le programme
        {
            List<statcards> ListeStat= manip.listeStats(equipe);
            System.out.println("\nMenu de l'application de gestion des Spurs : \n"); // On affiche le menu
            System.out.println("1 - Afficher les stats \n");
            System.out.println("2 - Ajouter les stats à la base de données \n");
            System.out.println("3 - Quitter le sous-menu \n");
            Scanner nombre = new Scanner(System.in);
			System.out.println("Saisir votre choix : ");
			choix = nombre.nextLine(); // On récupère le choix de l'utilisateur
            if (!choix.equals("3"))
            switch (choix) // On effectue le choix de l'utilisateur
            {
                case "1": // Afficher les matchs
                    manip.AfficherStats(ListeStat);
                    break;

                case "2": // Envoie des matchs dans la base
                    manip.StatsToBase(ListeStat);
                    break;

                default: // Si l'utilisateur entre autre chose que souhaité
                    System.out.println("Vous devez saisir un choix compris entre 1 et 2");
                    break;
            }
        }
        manip.afficherMenu();
    }
	
}
